# Custom language files #
If you want to add, change or extend language files use the `/Custom` directory.

Contents of custom language files will be loaded behind the regular language files and overwrite them.